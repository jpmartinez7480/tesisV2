<?php

    define("HOSTNAME",'db');
    define("PORT","");
    define("DATABASE","REPO");
    define("USERNAME","usach");
    define("PASSWORD","usach");
    